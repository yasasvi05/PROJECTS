package com.sch;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rec {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/recipes";
    private static final String USERNAME = "recipes";
    private static final String PASSWORD = "newpassword";

    public static void main(String[] args) {
        showHomePage();
    }

    private static void showHomePage() {
        JFrame homeFrame = new JFrame("Recipe Kitchen");
        homeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        homeFrame.setSize(800, 600);
        homeFrame.setLayout(null);

        // Load the background image
        ImageIcon backgroundIcon = new ImageIcon("C:\\Users\\DELL\\Pictures\\Screenshots\\Screenshot (716).png");
        Image image = backgroundIcon.getImage();
        Image scaledImage = image.getScaledInstance(800, 600, Image.SCALE_SMOOTH); // Scale the image to fit the frame
        JLabel backgroundLabel = new JLabel(new ImageIcon(scaledImage));
        backgroundLabel.setBounds(0, 0, 800, 600);

        // Add the background label to the content pane
        homeFrame.setContentPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(scaledImage, 0, 0, getWidth(), getHeight(), this);
            }
        });

        homeFrame.getContentPane().setLayout(null); // Ensure null layout for custom positioning

        // Title label
        JLabel titleLabel = new JLabel("RECIPE FINDER", JLabel.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 200, homeFrame.getWidth(), 50);
        homeFrame.getContentPane().add(titleLabel);

        // Next button
        JButton nextButton = new JButton("Next");
        nextButton.setFont(new Font("Arial", Font.BOLD, 20));
        nextButton.setBackground(new Color(255, 165, 0));
        nextButton.setForeground(Color.BLACK);
        nextButton.setBorderPainted(false);
        nextButton.setFocusPainted(false);
        nextButton.setBounds(300, 450, 200, 50);
        nextButton.addActionListener(e -> {
            homeFrame.dispose();
            showRecipeSearch();
        });
        homeFrame.getContentPane().add(nextButton);

        homeFrame.setVisible(true);
    }




    // Method for the next page (not implemented)



    private static void showRecipeSearch() {
        JFrame frame = new JFrame("Recipe Search");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        // Create a custom panel to draw the background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Set the background image
                ImageIcon backgroundImage = new ImageIcon("C:\\Users\\DELL\\Pictures\\rfinder.jpg");
                Image image = backgroundImage.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this); // Stretch image to cover the panel
            }
        };
        backgroundPanel.setLayout(new BorderLayout());
        frame.add(backgroundPanel, BorderLayout.CENTER);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setOpaque(false);  // Make the main panel transparent to show background image

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        inputPanel.setOpaque(false);  // Make input panel transparent

        // Increase the font size of the labels
        JLabel ingLabel = new JLabel("Enter Ingredient:");
        ingLabel.setFont(new Font("Arial", Font.BOLD, 20));  // Increased font size
        ingLabel.setForeground(Color.BLACK);

        JTextField ingField = new JTextField(20);  // Increased size
        ingField.setBackground(Color.WHITE);
        ingField.setFont(new Font("Arial", Font.PLAIN, 18));  // Increased font size

        JLabel catLabel = new JLabel("Category:");
        catLabel.setFont(new Font("Arial", Font.BOLD, 20));  // Increased font size
        catLabel.setForeground(Color.BLACK);

        String[] categories = {"Select Category", "Dinner", "Lunch", "Dessert", "Breakfast", "Snack", "Brunch", "Appetizer", "Side Dish"};
        JComboBox<String> categoryComboBox = new JComboBox<>(categories);
        categoryComboBox.setSelectedIndex(0); // Set "Select Category" as the default
        categoryComboBox.setBackground(Color.WHITE);
        categoryComboBox.setFont(new Font("Arial", Font.PLAIN, 18)); // Increased font size

        inputPanel.add(ingLabel);
        inputPanel.add(ingField);
        inputPanel.add(catLabel);
        inputPanel.add(categoryComboBox);

        mainPanel.add(inputPanel, BorderLayout.NORTH);

        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Arial", Font.BOLD, 22));  // Increased font size
        searchButton.setBackground(Color.WHITE);
        searchButton.setForeground(new Color(255, 165, 0));
        searchButton.setBorderPainted(false);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);  // Make button panel transparent
        buttonPanel.add(searchButton);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        DefaultListModel<String> recipeListModel = new DefaultListModel<>();
        JList<String> recipeList = new JList<>(recipeListModel);
        JScrollPane listScrollPane = new JScrollPane(recipeList);

        mainPanel.add(listScrollPane, BorderLayout.SOUTH);

        // Add mainPanel to backgroundPanel
        backgroundPanel.add(mainPanel, BorderLayout.CENTER);

        searchButton.addActionListener(e -> {
            String ing = ingField.getText().trim();
            String cat = (String) categoryComboBox.getSelectedItem();

            recipeListModel.clear();

            if (ing.isEmpty() || cat == null || cat.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in both fields.");
                return;
            }

            String query = "SELECT name FROM recipes WHERE ingredients LIKE ? AND category = ?";
            try (Connection con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                 PreparedStatement pst = con.prepareStatement(query)) {

                pst.setString(1, "%" + ing + "%");
                pst.setString(2, cat);
                ResultSet rs = pst.executeQuery();

                if (!rs.isBeforeFirst()) {
                    JOptionPane.showMessageDialog(frame, "No recipes found.");
                }
                while (rs.next()) {
                    recipeListModel.addElement(rs.getString("name"));
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
            }
        });

        recipeList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int index = recipeList.getSelectedIndex();
                    if (index >= 0) {
                        String selectedRecipe = recipeListModel.get(index);
                        showRecipeDetails(selectedRecipe);
                    }
                }
            }
        });

        frame.setVisible(true);
    }

    private static void showRecipeDetails(String recipeName) {
        JFrame detailFrame = new JFrame("Recipe Details - " + recipeName);
        detailFrame.setSize(800, 600);
        detailFrame.setLayout(new BorderLayout());

        // Background panel to display the image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon backgroundImage = new ImageIcon("E:\\downloads\\hand-drawn-food-background_23-2147849872.jpg"); // Update with your image path
                Image image = backgroundImage.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        backgroundPanel.setLayout(new GridBagLayout()); // Center the content panel
        detailFrame.add(backgroundPanel, BorderLayout.CENTER);

        // White overlay panel for the text content
        JPanel contentPanel = new JPanel(new BorderLayout(0, 0)); // Removed spacing between components
        contentPanel.setPreferredSize(new Dimension(600, 400)); // Smaller than the frame size
        contentPanel.setBackground(Color.WHITE); // White background for readability

        // Text area for displaying recipe details
        JTextArea detailArea = new JTextArea();
        detailArea.setEditable(false);
        detailArea.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        detailArea.setLineWrap(true); // Enable word wrapping
        detailArea.setWrapStyleWord(true); // Wrap at word boundaries

        // JScrollPane with vertical scrollbar only
        JScrollPane scrollPane = new JScrollPane(detailArea);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER); // Remove horizontal scrollbar
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED); // Show vertical scrollbar when needed

        contentPanel.add(scrollPane, BorderLayout.CENTER);

        try (Connection con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT ingredients, steps, nutritional_information, serving_suggestions FROM Recipes WHERE name = ?";
            try (PreparedStatement pst = con.prepareStatement(query)) {
                pst.setString(1, recipeName);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    StringBuilder details = new StringBuilder();
                    details.append("Ingredients:\n").append(rs.getString("ingredients")).append("\n\n");
                    details.append("Steps:\n").append(rs.getString("steps")).append("\n\n");
                    details.append("Nutritional Information:\n").append(rs.getString("nutritional_information")).append("\n\n");
                    details.append("Serving Suggestions:\n").append(rs.getString("serving_suggestions"));
                    detailArea.setText(details.toString());
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(detailFrame, "Error fetching recipe details: " + ex.getMessage());
        }

        // Add content panel to background panel
        backgroundPanel.add(contentPanel);
        detailFrame.setVisible(true);
    }

}
